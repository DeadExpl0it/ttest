// تخزين بيانات التابات اللي لسه ما سجلتش دخول
const pendingTabs = {};

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'login') {
    processEntries(message.entries);
    sendResponse({ status: 'started' });
  }
});

async function processEntries(entries) {
  for (const entry of entries) {
    try {
      const tab = await chrome.tabs.create({
        url: entry.url,
        active: false   // تتب في الخلفية
      });
      pendingTabs[tab.id] = {
        username: entry.username,
        password: entry.password
      };
    } catch (e) {
      console.error('Failed to create tab for', entry.url, e);
    }
  }
}

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && pendingTabs[tabId]) {
    const creds = pendingTabs[tabId];
    delete pendingTabs[tabId];   // نمسحه عشان ما يتكررش

    chrome.scripting.executeScript({
      target: { tabId: tabId },
      func: loginToWordPress,
      args: [creds.username, creds.password]
    }).catch(err => console.error('Injection failed for tab', tabId, err));
  }
});

// الدالة اللي هتتنفذ جوا كل صفحة تسجيل دخول
function loginToWordPress(username, password) {
  const logField = document.querySelector('input[name="log"]');
  const pwdField = document.querySelector('input[name="pwd"]');

  if (logField && pwdField) {
    // تعبئة الحقول
    logField.value = username;
    pwdField.value = password;

    // تحديد "تذكرني"
    const remember = document.querySelector('input[name="rememberme"]');
    if (remember) remember.checked = true;

    // التأكد من التوجيه للوحة التحكم بعد الدخول
    let redirect = document.querySelector('input[name="redirect_to"]');
    if (!redirect) {
      redirect = document.createElement('input');
      redirect.type = 'hidden';
      redirect.name = 'redirect_to';
      const form = document.querySelector('form#loginform');
      if (form) form.appendChild(redirect);
    }
    if (redirect) redirect.value = '/wp-admin';

    // إرسال النموذج
    const form = document.querySelector('form#loginform');
    if (form) {
      form.submit();
    } else {
      const submitBtn = document.querySelector('input[type="submit"]');
      if (submitBtn) submitBtn.click();
    }
  } else {
    // لو مش لاقي حقول تسجيل الدخول (يمكن داخل بالفعل) نحول للوحة التحكم مباشرة
    window.location.href = '/wp-admin';
  }
}