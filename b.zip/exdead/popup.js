document.getElementById('start').addEventListener('click', () => {
  const textarea = document.getElementById('links');
  const statusDiv = document.getElementById('status');
  const rawLines = textarea.value.split('\n');
  const entries = [];

  for (let line of rawLines) {
    line = line.trim();
    if (!line) continue;
    try {
      const urlObj = new URL(line);
      const baseUrl = urlObj.origin + urlObj.pathname;  // like /wp-login.php
      const frag = urlObj.hash.substring(1);           // text after #
      if (!frag) continue;
      const atIndex = frag.indexOf('@');
      if (atIndex === -1) continue;
      const username = frag.substring(0, atIndex);
      const password = frag.substring(atIndex + 1);
      if (!username || !password) continue;
      entries.push({ url: baseUrl, username, password });
    } catch (e) {
      console.warn('Skipping invalid URL:', line, e);
    }
  }

  if (entries.length === 0) {
    statusDiv.textContent = '❌ No valid entries found. Check format.';
    return;
  }

  statusDiv.textContent = `⏳ Processing ${entries.length} site(s)...`;
  chrome.runtime.sendMessage({ action: 'login', entries }, (response) => {
    if (chrome.runtime.lastError) {
      statusDiv.textContent = '❌ Error: ' + chrome.runtime.lastError.message;
    } else {
      statusDiv.textContent = `✅ Started ${entries.length} login tab(s). Check your browser tabs.`;
    }
  });
});